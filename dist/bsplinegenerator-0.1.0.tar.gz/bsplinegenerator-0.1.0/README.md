# Bspline_Generator
B-Spline Generator class

# Dependencies
Install the following

pip3 install numpy
pip3 install matplotlib

# Installation 
navigate to the working folder

/bspline_generator

then run the following command

pip install .

# Tutorial
Run the test_bsplines.py file to see how to use the class
